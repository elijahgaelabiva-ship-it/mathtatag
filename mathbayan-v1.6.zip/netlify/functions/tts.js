// MathBayan voice: turns a short lesson sentence into natural Gemini speech.
// The Gemini key lives ONLY here, as a Netlify environment variable (GEMINI_API_KEY).
// It is never placed in index.html. The app falls back to the phone's own voice if this fails.

const MODELS = [process.env.GEMINI_TTS_MODEL, "gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts"].filter(Boolean);
const VOICES = ["Leda", "Achird", "Kore", "Puck", "Aoede", "Zephyr", "Sulafat", "Callirrhoe"];
const STYLE = "Say this warmly, clearly and a little slowly, like a kind, cheerful teacher talking to a 7 year old child. Say numbers and math symbols naturally: ";
const MAX_CHARS = 700;

// very small per-instance throttle so a stray script cannot drain the key
const hits = new Map();
function throttled(ip) {
  const now = Date.now(), win = 60000, max = 60;
  const a = (hits.get(ip) || []).filter(t => now - t < win);
  a.push(now); hits.set(ip, a);
  if (hits.size > 500) hits.clear();
  return a.length > max;
}

// Gemini returns raw 16-bit PCM (24 kHz, mono). Browsers need a WAV header on it.
function wav(pcm, rate = 24000) {
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + pcm.length, 4); h.write("WAVE", 8);
  h.write("fmt ", 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22);
  h.writeUInt32LE(rate, 24); h.writeUInt32LE(rate * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34);
  h.write("data", 36); h.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([h, pcm]);
}

const json = (code, o) => ({ statusCode: code, headers: { "content-type": "application/json" }, body: JSON.stringify(o) });

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "POST only" });
  const key = process.env.GEMINI_API_KEY;
  if (!key) return json(503, { error: "Voice is not set up yet (missing GEMINI_API_KEY)" });

  const allowed = process.env.ALLOWED_ORIGIN; // optional, e.g. https://mathbayan.netlify.app
  const origin = event.headers.origin || event.headers.Origin || "";
  if (allowed && origin && origin !== allowed) return json(403, { error: "Origin not allowed" });

  const ip = (event.headers["x-nf-client-connection-ip"] || event.headers["x-forwarded-for"] || "x").split(",")[0].trim();
  if (throttled(ip)) return json(429, { error: "Slow down a little" });

  let body;
  try { body = JSON.parse(event.body || "{}"); } catch (e) { return json(400, { error: "Bad JSON" }); }
  const text = String(body.text || "").trim().slice(0, MAX_CHARS);
  const voice = VOICES.includes(body.voice) ? body.voice : "Leda";
  if (!text) return json(400, { error: "No text" });

  let lastErr = "no model worked";
  for (const model of MODELS) {
    try {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({
          contents: [{ parts: [{ text: STYLE + text }] }],
          generationConfig: {
            responseModalities: ["AUDIO"],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } }
          }
        })
      });
      if (!r.ok) { lastErr = model + " -> HTTP " + r.status; if (r.status === 404 || r.status === 400) continue; if (r.status === 429) return json(429, { error: "Voice is busy" }); continue; }
      const d = await r.json();
      const part = d && d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts && d.candidates[0].content.parts.find(p => p.inlineData);
      if (!part) { lastErr = model + " -> no audio"; continue; }
      const m = /rate=(\d+)/.exec(part.inlineData.mimeType || "");
      const out = wav(Buffer.from(part.inlineData.data, "base64"), m ? +m[1] : 24000);
      return { statusCode: 200, headers: { "content-type": "audio/wav", "cache-control": "no-store" }, body: out.toString("base64"), isBase64Encoded: true };
    } catch (e) { lastErr = model + " -> " + (e && e.message); }
  }
  return json(502, { error: lastErr });
};
