# MathBayan v1.3 – turning on the Gemini voice

1. Get a Gemini API key (Google AI Studio). Set a daily quota/budget limit on it.
2. In Netlify: Site configuration > Environment variables > add
   GEMINI_API_KEY = your key
   (optional) ALLOWED_ORIGIN = https://your-site.netlify.app   (blocks other websites from using your key)
   (optional) GEMINI_TTS_MODEL = a newer Gemini TTS model name, if Google retires the built-in ones
3. Deploy the WHOLE folder (it now contains netlify/functions/tts.js and netlify.toml).
   The key stays on Netlify. It is never inside index.html.
4. Open the app > Parent view > Buddy voice > pick a voice.

If the function is missing or the key is not set, the app quietly uses the phone's own voice instead.
Voices already played are saved on the device, so they work again offline.
